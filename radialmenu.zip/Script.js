
    var shared = document.querySelector(".SHARED");
    var shared2 = document.querySelector(".SHARED2");
    var cabin = document.querySelector(".CABIN");
    var cabin2 = document.querySelector(".CABIN2");
    var sed = document.querySelector(".SED");
    var sed1 = document.querySelector(".SED1");
    var sed2 = document.querySelector(".SED22");
    var sep = document.querySelector(".SEP");
    var sep1 = document.querySelector(".SEP1");
    var sep2 = document.querySelector(".SEP2");
    var sao = document.querySelector(".SAO");
    var sao1 = document.querySelector(".SA01");
    var sao2 = document.querySelector(".SA02");
    var sao3 = document.querySelector(".SA03");
    var seats = document.querySelector(".SEATS");
    var seats1 = document.querySelector(".SEATS1");
    var seats2 = document.querySelector(".SEATS2");
    var seats3 = document.querySelector(".SEATS3");

    var rgbcode = "rgb(123, 227, 21)";

    var seats_almond = document.querySelector(".menunav .almond");
    var shared_grape = document.querySelector(".menunav .grape");
    var cabin_blackberry = document.querySelector(".menunav .blackberry");
    var sep_cherry = document.querySelector(".menunav .cherry");
    var sao_coconut = document.querySelector(".menunav .coconut");
    var sed_vanilla = document.querySelector(".menunav .vanilla");

    shared.addEventListener("click", function () {

        shared.style.backgroundColor = shared.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        shared2.style.backgroundColor = shared2.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;


    });

    shared2.addEventListener("click", function () {

        shared.style.backgroundColor = shared.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        shared2.style.backgroundColor = shared2.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;


    });





    // -----------------------------------------------------

    cabin.addEventListener("click", function () {

        cabin.style.backgroundColor = cabin.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        cabin2.style.backgroundColor = cabin2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;


    });

    cabin2.addEventListener("click", function () {

        cabin.style.backgroundColor = cabin.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        cabin2.style.backgroundColor = cabin2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;


    });

    // -----------------------------------------------------


    sed.addEventListener("click", function () {

        sed.style.backgroundColor = sed.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sed1.style.backgroundColor = sed1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sed2.style.backgroundColor = sed2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;

    });


    sed1.addEventListener("click", function () {

        sed.style.backgroundColor = sed.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sed1.style.backgroundColor = sed1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;

    });
    sed2.addEventListener("click", function () {

        sed.style.backgroundColor = sed.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sed2.style.backgroundColor = sed2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;

    });

    // -----------------------------------------------------

    sep.addEventListener("click", function () {

        sep.style.backgroundColor = sep.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sep1.style.backgroundColor = sep1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sep2.style.backgroundColor = sep2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;


    });

    sep1.addEventListener("click", function () {

        sep.style.backgroundColor = sep.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sep1.style.backgroundColor = sep1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;


    });
    sep2.addEventListener("click", function () {

        sep.style.backgroundColor = sep.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sep2.style.backgroundColor = sep2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;


    });


    // -----------------------------------------------------

    seats.addEventListener("click", function () {
        seats.style.backgroundColor = seats.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        seats1.style.backgroundColor = seats1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        seats2.style.backgroundColor = seats2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        seats3.style.backgroundColor = seats3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });


    seats1.addEventListener("click", function () {
        seats.style.backgroundColor = seats.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        seats1.style.backgroundColor = seats1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });

    seats2.addEventListener("click", function () {
        seats.style.backgroundColor = seats.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        seats2.style.backgroundColor = seats2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });

    seats3.addEventListener("click", function () {
        seats.style.backgroundColor = seats.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        seats3.style.backgroundColor = seats3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });



    // -----------------------------------------------------
    sao.addEventListener("click", function () {
        sao.style.backgroundColor = sao.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sao1.style.backgroundColor = sao1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sao2.style.backgroundColor = sao2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sao3.style.backgroundColor = sao3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });


    sao1.addEventListener("click", function () {
        sao.style.backgroundColor = sao.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sao1.style.backgroundColor = sao1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });

    sao2.addEventListener("click", function () {
        sao.style.backgroundColor = sao.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sao2.style.backgroundColor = sao2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });

    sao3.addEventListener("click", function () {
        sao.style.backgroundColor = sao.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sao3.style.backgroundColor = sao3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
    });




    // --------------------------------------------------
    // --------------------------------------------------

    document.querySelector(".safran").addEventListener("click", function () {
        shared.style.backgroundColor = shared.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        shared2.style.backgroundColor = shared2.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        cabin.style.backgroundColor = cabin.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        cabin2.style.backgroundColor = cabin2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sed.style.backgroundColor = sed.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sed1.style.backgroundColor = sed1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sed2.style.backgroundColor = sed2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sep.style.backgroundColor = sep.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sep1.style.backgroundColor = sep1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sep2.style.backgroundColor = sep2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sao.style.backgroundColor = sao.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        sao1.style.backgroundColor = sao1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sao2.style.backgroundColor = sao2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        sao3.style.backgroundColor = sao3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        seats.style.backgroundColor = seats.style.backgroundColor === rgbcode ? "#1da5c3" : rgbcode;
        seats1.style.backgroundColor = seats1.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        seats2.style.backgroundColor = seats2.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;
        seats3.style.backgroundColor = seats3.style.backgroundColor === rgbcode ? "#27D2AB" : rgbcode;

    });

    // -------------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------------


    $(document).ready(function () {

        var audio = new Audio('https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/click.mp3');
        var audio2 = new Audio('https://s3-us-west-2.amazonaws.com/s.cdpn.io/242518/clickUp.mp3')

        $(".safran").mousedown(function () {
            audio2.load();
            audio2.play();
        });

        $(".safran").mouseup(function () {
            audio.load();
            audio.play();
        });
    });


